# Android Things Robot
Android Things robot, controlled by  web interface with: camera, servo, distance sensor(hc-sr04), lcd display(ssd1306), rgb led, halt button, motor-driver (h-bridge), dc motors.

###Click on image below to play video.
[![androd things robot video ](/img/robot.jpg?raw=true "Android Things Robot")](https://www.youtube.com/watch?v=kqzAsOs99Dc) 

### SSD1306
![Android Things lcd ssd 1306](/img/ssd1306.jpg?raw=true "")

### HC-SR04
![Android Things HC-SR04](/img/hc-sr04-02.jpg?raw=true "")

### RGB Led
![Android Things RGB led](/img/rgb.jpg?raw=true "")

### halt button
![Android Things push button](/img/btn.jpg?raw=true "")

### Motor driver
![Android Things motor driver H-bridge ](/img/h-bridge.jpg?raw=true "")

### DC Motor
![Android Things DC motor ](/img/motor.jpg?raw=true "")

### Micro Servo 9g
![Android Things micro servo 9g](/img/servo.jpg?raw=true "")

### Raspberry Pi 3 with Camera 
![Android Things Raspberry Pi 3 with Camera](/img/raspberry_pi_3.jpg?raw=true "")

#Wiring

#Software Architecture	

