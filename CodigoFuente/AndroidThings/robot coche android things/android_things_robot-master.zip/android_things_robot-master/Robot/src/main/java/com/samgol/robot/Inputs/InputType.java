package com.samgol.robot.Inputs;

public enum InputType {
	COMMAND, OBSTACLE, HALT, TIME, CAMERA
}
