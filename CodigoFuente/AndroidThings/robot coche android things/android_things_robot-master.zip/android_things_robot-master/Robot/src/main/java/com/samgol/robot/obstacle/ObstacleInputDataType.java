package com.samgol.robot.obstacle;

/**
 * Created by x on 1/8/17.
 */

public enum ObstacleInputDataType {
    CLOSE, FAR, NEAR
}
