package com.samgol.robot.remoteControl;

/**
 * Created by x on 1/7/17.
 */

public interface CommandListener {
    void onCommand(String command);
}
