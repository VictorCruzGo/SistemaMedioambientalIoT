package com.samgol.robot.camera;

/**
 * Created by x on 1/30/17.
 */

public enum CamInputType {
    SHOT_COMPLETED
}
