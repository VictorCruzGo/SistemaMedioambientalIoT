Android Things - Hello Things
=====================================

This is a hello world project for Android Things on Raspberry Pi.<br>
It demonstrate Blink an LED code sample at the [Android Developer website](https://developer.android.com/things/training/first-device/peripherals.html)

