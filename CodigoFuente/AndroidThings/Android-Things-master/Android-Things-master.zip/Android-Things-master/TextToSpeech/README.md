Android Things - Text To Speech
=================================

Example to showcase Text To Speech capability of Android Things using USB speakers

