Android Things - Motor Control using L293D
===========================================

This project demonstrate integration and control of DC Motor from PUSH button as input on Android Things.<br>
When button is pressed, output goes LOW and Motor starts. As soon as there button is released, output goes HIGH and Motor is turned off.<br>
[L293D Motor Control module](http://www.amazon.in/Elementz-Stepper-Driver-Raspberry-Arduino/dp/B00LMY58TG) is used to interface DC Motor with Raspberry Pi with Android Things.<br><br>
[![DC Motor Control using L293D on Android Things](https://i9.ytimg.com/vi/nVNLk_6A0mQ/2.jpg?sqp=COjFgMMF&rs=AOn4CLAkXrQtzEE0iiZmlHdoHUkLaNmTIg&time=1482695682724)](https://youtu.be/nVNLk_6A0mQ)
