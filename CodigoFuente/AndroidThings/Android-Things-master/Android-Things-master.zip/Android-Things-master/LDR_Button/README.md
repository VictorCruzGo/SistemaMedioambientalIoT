Android Things - LDR Button
=====================================

This project demonstrate use of LDR (Light Dependant Resistor) as a toggle button on Android Things.<br>
When it's dark, LDR output goes LOW and LED glows. As soon as there is light, LDR output goes HIGH and LED is turned off.<br><br>
[![LDR as Button on Android Things](https://i9.ytimg.com/vi/BZvCmYr1Ja8/2.jpg?sqp=COzS5cIF&rs=AOn4CLBZIgnJJ0K_ULsQH6SVo4oBCNLx5Q&time=1482254939361)](https://youtu.be/BZvCmYr1Ja8)
