Android Things - Ultrasonic Distance Calculator
================================================

This experiment demonstrate use of Ultrasonic sensor with Android-Things on Raspberry Pi