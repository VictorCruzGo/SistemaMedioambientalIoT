Android Things empty project template
=====================================

Testing to use Speech to Text API from Android on Android Things. But it's not supported right now.
