Android Things - BLE Beacon
=====================================

This project demonstrate how to enable BLE features on Android Things and create a Beacon to advertise a message.<br><br>
[![BLE Beacon on Android Things](https://www.youtube.com/upload_thumbnail?v=6hb4-VhsoSI&t=hqdefault&ts=1508596298951)](https://youtu.be/6hb4-VhsoSI)
