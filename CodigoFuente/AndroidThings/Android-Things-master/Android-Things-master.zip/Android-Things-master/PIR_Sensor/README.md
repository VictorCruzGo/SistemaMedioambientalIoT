Android Things empty project template
=====================================

This project demonstrates use of PIR motion sensor (Infrared motion detector) as a button on Android Things.<br>
When there is movement by heat emitting body near PIR sensor, it's output goes HIGH and LED glows. When no motion is detected, PIR output goes LOW and LED is turned off.<br><br>
[![PIR sensor on Android Things](https://i9.ytimg.com/vi/uMHb5H8H-Nk/2.jpg?sqp=CNCd9MMF&rs=AOn4CLDIL_0VBlU--KdQzS9gfiItMG52wQ&time=1484590853711)](https://youtu.be/uMHb5H8H-Nk)
